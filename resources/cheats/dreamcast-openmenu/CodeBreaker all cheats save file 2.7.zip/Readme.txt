
After several years of manually inputting Codebreaker codes using the DC controller whenever I wanted to try a new game, I discovered Xplorer DC Code Compiler recently and decided to put together a complete CodeBreaker cheats file containing:

- all unique codes from GameHacking.org
- codes already built into CodeBreaker
- widescreen codes
- other codes from the Dreamcast-Talk forum


I used the following criteria to determine which codes to add:

- one game one region (1G1R) - this is mostly USA with some Japan-only games but there are a few games which I included PAL cheats for due to one of the following reasons:
	- I've personally played through those games in their entirety using those codes and found they worked better than their NTSC equivalents (e.g. Record of Lodoss War, Silver)
	- cheat code creators have posted codes for a PAL version of a game which have no NTSC equivalent

- all codes are decrypted (CodeBreaker/XplorerDC format). Any encrypted (Action Replay/GameShark format) codes have been converted to decrypted format using DCcrypt


I've included:

- fcdcheats (openMenu).txt file containing all the codes (this can be loaded into Xplorer DC Code Compiler and edited further)

- the resulting FCDCHEATS.BIN file generated from fcdcheats.txt, ready for use with openMenu. Unlike previous versions of this cheats file, this will NOT fit on a standard 200 block VMU. If you require a version of the cheats file that will fit on a VMU, please use version 1.2 instead - this takes up 198 out of 200 blocks on a VMU


Instructions (courtesy of ateam):

Extract FCDCHEATS.BIN from the ZIP file then copy it to the following folder inside GDMENU Card Manager, overwriting the old one:

OPENMENU\GDMENUCardManager.v2.0.1-win-x64\tools\openMenu\menu_data\cheats\

Of course, you must then open GDMENU Card Manager with your SD card loaded, then click "Save Changes" in order to rebuild openMenu with the new cheat database.